export const loginURL = 'https://wordpress.trustysystem.com//wp-json/custom-login/v1/login'

export const logoutURL = 'https://wordpress.trustysystem.com//wp-json/custom-login/v1/logout'