import React from "react";

const Content = () => {
  return <main id="main" className="main">
    
  </main>;
};

export default Content;
